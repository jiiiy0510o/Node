//express 프레임워크 실행
const express = require("express");
const app = express();
const { MongoClient, ObjectId } = require("mongodb");
//PUT/DELETE 요청 가능
const methodOverride = require("method-override");
const bcrypt = require("bcrypt");
require("dotenv").config();

app.use(methodOverride("_method"));
//static 파일들 폴더 서버등록
app.use(express.static(__dirname + "/public"));
app.set("view engine", "ejs");
//req.body 쓰려면 필수
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//라우터 설정
app.use("/", require("./routes/list.js"));
app.use("/", require("./routes/write.js"));
app.use("/", require("./routes/edit.js"));

//passport 라이브러리 셋팅
const session = require("express-session");
const passport = require("passport");
const LocalStrategy = require("passport-local");
const MongoStore = require("connect-mongo");

app.use(passport.initialize());
app.use(
  session({
    secret: "암호화에 쓸 비번",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 60 * 60 * 1000 },
    store: MongoStore.create({
      mongoUrl: process.env.DB_URL,
      dbName: "forum",
    }),
  })
);

app.use(passport.session());

let db;
let connectDB = require("./database.js");

connectDB
  .then((client) => {
    console.log("DB연결성공");
    db = client.db("forum");
    //성공시 서버 실행 코드
    app.listen(process.env.PORT, () => {
      console.log("http://localhost:8080 에서 서버 실행중");
    });
  })
  .catch((err) => {
    console.log(err);
  });

// 페이지 접속시 응답(라우팅)
app.get("/", (req, res) => {
  //File 전송시
  res.sendFile(__dirname + "/index.html");
});

app.get("/detail/:id", async (req, res) => {
  try {
    let result = await db.collection("post").findOne({ _id: new ObjectId(req.params.id) });
    res.render("detail.ejs", { result: result });
  } catch (e) {
    res.status(404).send("URL ERROR");
  }
});

//제출 한 아이디/비번 검사하는 코드
passport.use(
  new LocalStrategy(async (입력한아이디, 입력한비번, cb) => {
    let result = await db.collection("user").findOne({ username: 입력한아이디 });
    if (!result) {
      return cb(null, false, { message: "아이디 DB에 없음" });
    }

    if (await bcrypt.compare(입력한비번, result.password)) {
      return cb(null, result);
    } else {
      return cb(null, false, { message: "비번불일치" });
    }
  })
);

passport.serializeUser((user, done) => {
  //내부코드를 비동기적으로 처리해줌
  process.nextTick(() => {
    done(null, { id: user._id, username: user.username });
  });
});
//유저가 보낸 쿠키분석
passport.deserializeUser(async (user, done) => {
  let result = await db.collection("user").findOne({ _id: new ObjectId(user.id) });
  delete result.password;
  process.nextTick(() => {
    done(null, result);
  });
});

app.get("/write", (req, res) => {
  console.log(req.user);

  if (req.user == undefined) {
    res.send("로그인해주세요");
  } else {
    res.render("write.ejs");
  }
});

app.get("/login", async (req, res) => {
  res.render("login.ejs");
});

app.post(
  "/login",
  function gapChk(req, res, next) {
    if (req.body.username == "" || req.body.password == "") {
      res.send("hh");
    } else {
      next();
    }
  },
  async (req, res, next) => {
    passport.authenticate("local", (error, user, info) => {
      if (error) return res.status(500).json(error);
      if (!user) return res.status(401).json(info.message);
      req.logIn(user, (err) => {
        if (err) return next(err);
        res.redirect("/");
      });
    })(req, res, next);
  }
);

app.get("/myPage", (req, res) => {
  if (!req.user) {
    res.send("로그인해주세요");
  } else {
    let username = req.user.username;
    res.render("myPage.ejs", { username: username });
  }
});

app.post("/register", async (req, res) => {
  let password = await bcrypt.hash(req.body.password, 10);

  await db.collection("user").insertOne({ username: req.body.username, password: password });
  res.redirect("/");
});
app.get("/register", async (req, res) => {
  console.log(req.body);
  res.render("register.ejs");
});

app.post("/chkDuplication", async (req, res) => {
  let result = await db.collection("user").findOne({ username: req.body.username });
  res.send({ result: result });
  console.log(result);
});
