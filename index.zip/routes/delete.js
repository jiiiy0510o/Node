const router = require("express").Router();
const { ObjectId } = require("mongodb");
let connectDB = require("./../database.js");

let db;

connectDB
  .then((client) => {
    db = client.db("forum");
  })
  .catch((err) => {
    console.log(err);
  });

router.delete("/delete", async (req, res) => {
  await db.collection("post").deleteOne({ _id: new ObjectId(req.query.id) });
  console.log(req.query);
  res.send("삭제완료");
});

module.exports = router;
