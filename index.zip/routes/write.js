const router = require("express").Router();
const { S3Client } = require("@aws-sdk/client-s3");
const multer = require("multer");
const multerS3 = require("multer-s3");

let connectDB = require("./../database.js");

let db;
const s3 = new S3Client({
  region: "ap-northeast-2",
  credentials: {
    accessKeyId: process.env.IM_KEY,
    secretAccessKey: process.env.IM_SECRET,
  },
});

const upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: "gnuoy-j",
    key: function (요청, file, cb) {
      cb(null, Date.now().toString()); //업로드시 파일명 변경가능
    },
  }),
});

connectDB
  .then((client) => {
    db = client.db("forum");
  })
  .catch((err) => {
    console.log(err);
  });

router.post("/new-post", async (req, res) => {
  upload.single("img1")(req, res, async (err) => {
    if (err) return res.send("img 업로드 에러");
    //이미지 업로드 완료시 실행할 코드
    try {
      if (req.body.title == "") {
        res.send("빈칸");
      } else if (req.body.content == "") {
        res.send("내용빈칸");
      } else {
        await db
          .collection("post")
          .insertOne({ title: req.body.title, content: req.body.content, img: req.file.location });
        res.redirect("/list");
      }
    } catch (e) {
      res.send("서버에러");
    }
  });
});

module.exports = router;
